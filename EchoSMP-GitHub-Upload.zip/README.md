# Echo Anarchy SMP (Paper 1.21.11)

## Build
Java 21 and Gradle required. Run `gradle build` from this folder. The output JAR will be in `build/libs/`.

## Install
Put the compiled JAR into your Paper server `plugins/` folder, then restart. The plugin automatically extracts `plugins/EchoAnarchySMP/EchoAnarchySMP-resourcepack.zip`. Upload this resourcepack ZIP to a publicly accessible HTTPS URL and set `resource-pack` (and ideally `require-resource-pack=true`) in `server.properties` so players can see the 3D models. The JAR itself cannot transmit resourcepack assets without a hosted pack URL.

## Rules
Coal Haste I; Copper Speed I; Iron Strength I; Gold Strength I and Speed I; Diamond Strength I and Speed II; Netherite Strength II, Speed II and Resistance I. Valid PvP kills required per upgrade: 1, then 2, 3, 4, 5. A given killer/victim pair counts once every 2 hours, persisted in `players.yml`. All deaths reset the victim to Coal and drop their former shard as a pickup item. Better dropped shards upgrade the picker; weaker ones don't downgrade them. Only one Netherite may exist at once, including a Netherite item on the ground. `/shard` displays progress.

## Notes
The special shard is a server-side level; an item is spawned only on death. Do not manually delete a dropped Netherite item: it remains reserved to prevent duplication and would need admin recovery. Server backups are recommended. This source is provided uncompiled and has not been integration-tested on a live Paper server. 3D models are stylized block crystals and may need visual adjustment.
