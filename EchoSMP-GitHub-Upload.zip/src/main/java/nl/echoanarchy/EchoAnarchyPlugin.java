package nl.echoanarchy;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import java.io.*;
import java.util.*;

public final class EchoAnarchyPlugin extends JavaPlugin implements Listener {
    private static final String[] NAMES={"Coal","Copper","Iron","Gold","Diamond","Netherite"};
    private static final int[] NEED={1,2,3,4,5};
    private static final Material[] MATERIALS={Material.COAL,Material.COPPER_INGOT,Material.IRON_INGOT,Material.GOLD_INGOT,Material.DIAMOND,Material.NETHERITE_INGOT};
    private static final ChatColor[] COLORS={ChatColor.DARK_GRAY,ChatColor.GOLD,ChatColor.GRAY,ChatColor.YELLOW,ChatColor.AQUA,ChatColor.DARK_PURPLE};
    private static final long COOLDOWN=2*60*60*1000L;
    private final Map<UUID,Integer> levels=new HashMap<>(),progress=new HashMap<>();
    private final Map<String,Long> lastKills=new HashMap<>();
    private NamespacedKey shardKey;
    private File file;
    // Netherite exists either as an owned shard or as a dropped shard. A dropped shard is tracked by item UUID.
    private UUID netheriteOwner,netheriteDrop;

    @Override public void onEnable(){
        shardKey=new NamespacedKey(this,"dropped_shard");
        file=new File(getDataFolder(),"players.yml");
        load();
        extractResourcePack();
        Bukkit.getPluginManager().registerEvents(this,this);
        for(Player p:Bukkit.getOnlinePlayers()) apply(p);
        Bukkit.getScheduler().runTaskTimer(this,()->{
            for(Player p:Bukkit.getOnlinePlayers()) apply(p);
            if(netheriteDrop!=null && findDrop(netheriteDrop)==null){
                // Do not free Netherite on chunk unload: unloaded items are not findable.
            }
        },40L,100L);
    }
    @Override public void onDisable(){save();}
    private void extractResourcePack(){
        File target=new File(getDataFolder(),"EchoAnarchySMP-resourcepack.zip");
        if(target.exists())return;
        getDataFolder().mkdirs();
        try(java.io.InputStream in=getResource("EchoAnarchySMP-resourcepack.zip")){
            if(in!=null)java.nio.file.Files.copy(in,target.toPath());
        }catch(Exception ex){getLogger().warning("Resourcepack extraction failed: "+ex.getMessage());}
    }
    private void load(){
        YamlConfiguration c=YamlConfiguration.loadConfiguration(file);
        if(c.isConfigurationSection("players")) for(String s:c.getConfigurationSection("players").getKeys(false)) try{
            UUID id=UUID.fromString(s);
            levels.put(id,Math.max(0,Math.min(5,c.getInt("players."+s+".level"))));
            progress.put(id,Math.max(0,c.getInt("players."+s+".progress")));
        }catch(IllegalArgumentException ignored){}
        if(c.isConfigurationSection("cooldowns")) for(String s:c.getConfigurationSection("cooldowns").getKeys(false)) lastKills.put(s,c.getLong("cooldowns."+s));
        try{String s=c.getString("netherite-owner");if(s!=null)netheriteOwner=UUID.fromString(s);}catch(IllegalArgumentException ignored){}
        try{String s=c.getString("netherite-drop");if(s!=null)netheriteDrop=UUID.fromString(s);}catch(IllegalArgumentException ignored){}
        for(UUID id:new HashSet<>(levels.keySet())) if(levels.get(id)==5 && !id.equals(netheriteOwner))levels.put(id,4);
        if(netheriteOwner!=null && levels.getOrDefault(netheriteOwner,0)!=5)netheriteOwner=null;
    }
    private void save(){
        YamlConfiguration c=new YamlConfiguration();
        for(UUID id:levels.keySet()){
            c.set("players."+id+".level",levels.get(id));
            c.set("players."+id+".progress",progress.getOrDefault(id,0));
        }
        for(var e:lastKills.entrySet())c.set("cooldowns."+e.getKey(),e.getValue());
        c.set("netherite-owner",netheriteOwner==null?null:netheriteOwner.toString());
        c.set("netherite-drop",netheriteDrop==null?null:netheriteDrop.toString());
        try{c.save(file);}catch(IOException ex){getLogger().severe("Could not save players.yml: "+ex.getMessage());}
    }
    private int level(UUID id){return levels.getOrDefault(id,0);}
    private void setLevel(Player p,int lv){
        UUID id=p.getUniqueId();
        if(level(id)==5 && id.equals(netheriteOwner) && lv!=5)netheriteOwner=null;
        levels.put(id,lv);progress.put(id,0);
        if(lv==5){netheriteOwner=id;netheriteDrop=null;}
        apply(p);save();
    }
    private void effect(Player p,PotionEffectType type,int amp){p.addPotionEffect(new PotionEffect(type,240,amp,true,false,false));}
    private void apply(Player p){
        int lv=level(p.getUniqueId());
        p.removePotionEffect(PotionEffectType.HASTE);p.removePotionEffect(PotionEffectType.SPEED);
        p.removePotionEffect(PotionEffectType.STRENGTH);p.removePotionEffect(PotionEffectType.RESISTANCE);
        switch(lv){
            case 0 -> effect(p,PotionEffectType.HASTE,0);
            case 1 -> effect(p,PotionEffectType.SPEED,0);
            case 2 -> effect(p,PotionEffectType.STRENGTH,0);
            case 3 -> {effect(p,PotionEffectType.STRENGTH,0);effect(p,PotionEffectType.SPEED,0);}
            case 4 -> {effect(p,PotionEffectType.STRENGTH,0);effect(p,PotionEffectType.SPEED,1);}
            case 5 -> {effect(p,PotionEffectType.STRENGTH,1);effect(p,PotionEffectType.SPEED,1);effect(p,PotionEffectType.RESISTANCE,0);}
        }
        p.setPlayerListName(COLORS[lv]+"["+NAMES[lv]+"] "+ChatColor.RESET+p.getName());
    }
    private ItemStack shardItem(int lv){
        ItemStack stack=new ItemStack(MATERIALS[lv]);
        ItemMeta meta=stack.getItemMeta();
        meta.setDisplayName(COLORS[lv]+NAMES[lv]+" Shard");
        meta.setItemModel(new NamespacedKey("echoanarchy",NAMES[lv].toLowerCase()+"_shard"));
        meta.setLore(List.of(ChatColor.GRAY+"Echo Anarchy SMP",ChatColor.GRAY+"Pak op om je shard te verbeteren"));
        meta.getPersistentDataContainer().set(shardKey,PersistentDataType.INTEGER,lv);
        stack.setItemMeta(meta);return stack;
    }
    private int shardLevel(ItemStack stack){
        if(stack==null || !stack.hasItemMeta())return -1;
        Integer n=stack.getItemMeta().getPersistentDataContainer().get(shardKey,PersistentDataType.INTEGER);
        return n==null?-1:n;
    }
    private Item findDrop(UUID id){
        for(World w:Bukkit.getWorlds())for(Item item:w.getEntitiesByClass(Item.class))if(item.getUniqueId().equals(id))return item;
        return null;
    }
    @EventHandler public void onJoin(PlayerJoinEvent e){
        UUID id=e.getPlayer().getUniqueId();levels.putIfAbsent(id,0);progress.putIfAbsent(id,0);
        Bukkit.getScheduler().runTaskLater(this,()->{if(e.getPlayer().isOnline())apply(e.getPlayer());},2);
        save();
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent e){Bukkit.getScheduler().runTaskLater(this,()->apply(e.getPlayer()),2);}
    @EventHandler public void onDeath(PlayerDeathEvent e){
        Player dead=e.getEntity();UUID victim=dead.getUniqueId();int old=level(victim);
        // The shard is not a normal inventory item. It only materializes as an item upon death.
        Item dropped=dead.getWorld().dropItemNaturally(dead.getLocation(),shardItem(old));
        dropped.setUnlimitedLifetime(true);
        if(old==5){netheriteOwner=null;netheriteDrop=dropped.getUniqueId();}
        levels.put(victim,0);progress.put(victim,0);
        Player killer=dead.getKiller();
        if(killer!=null && !killer.getUniqueId().equals(victim)){
            String key=killer.getUniqueId()+"_"+victim;
            long now=System.currentTimeMillis();long last=lastKills.getOrDefault(key,0L);
            if(now-last>=COOLDOWN){
                lastKills.put(key,now);
                int lv=level(killer.getUniqueId());
                if(lv==5)killer.sendMessage(ChatColor.LIGHT_PURPLE+"Je hebt de hoogste Shard al!");
                else if(lv==4 && (netheriteOwner!=null || netheriteDrop!=null)){
                    killer.sendMessage(ChatColor.YELLOW+"Netherite bestaat al. Je blijft Diamond.");
                }else{
                    int count=progress.merge(killer.getUniqueId(),1,Integer::sum);
                    if(count>=NEED[lv]){
                        setLevel(killer,lv+1);
                        Bukkit.broadcastMessage(ChatColor.AQUA+killer.getName()+" heeft " + COLORS[lv+1]+NAMES[lv+1]+" Shard"+ChatColor.AQUA+" bereikt!");
                    }else killer.sendMessage(ChatColor.GREEN+"Geldige kill! "+count+"/"+NEED[lv]+" voor de volgende Shard.");
                }
            }else killer.sendMessage(ChatColor.RED+"Deze speler telt pas over "+((COOLDOWN-(now-last)+59999)/60000)+" minuten opnieuw mee.");
        }
        save();
    }
    @EventHandler public void onPickup(EntityPickupItemEvent e){
        int lv=shardLevel(e.getItem().getItemStack());if(lv<0)return;
        e.setCancelled(true);
        if(!(e.getEntity() instanceof Player p))return;
        if(lv<=level(p.getUniqueId())){p.sendMessage(ChatColor.GRAY+"Je hebt al een even goede of betere Shard.");return;}
        if(lv==5 && (netheriteDrop==null || !netheriteDrop.equals(e.getItem().getUniqueId())))return;
        if(lv==5 && netheriteOwner!=null && !netheriteOwner.equals(p.getUniqueId()))return;
        e.getItem().remove();
        setLevel(p,lv);
        p.sendMessage(ChatColor.GREEN+"Je hebt de "+COLORS[lv]+NAMES[lv]+" Shard"+ChatColor.GREEN+" opgepakt!");
    }
    @EventHandler public void onHopper(org.bukkit.event.inventory.InventoryPickupItemEvent e){if(shardLevel(e.getItem().getItemStack())>=0)e.setCancelled(true);}
    @EventHandler public void onDespawn(ItemDespawnEvent e){if(shardLevel(e.getEntity().getItemStack())>=0)e.setCancelled(true);}
    @EventHandler public void onCommandPreprocess(PlayerCommandPreprocessEvent e){/* reserved */}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!command.getName().equalsIgnoreCase("shard"))return false;
        if(!(sender instanceof Player p)){sender.sendMessage("Alleen spelers.");return true;}
        int lv=level(p.getUniqueId());
        p.sendMessage(COLORS[lv]+"Jouw Shard: "+NAMES[lv]);
        if(lv==5)p.sendMessage(ChatColor.LIGHT_PURPLE+"Maximale Shard!");
        else p.sendMessage(ChatColor.YELLOW+"Voortgang: "+progress.getOrDefault(p.getUniqueId(),0)+"/"+NEED[lv]+" geldige kills");
        p.sendMessage(ChatColor.GRAY+"Dezelfde speler telt maar 1x per 2 uur mee.");return true;
    }
}
